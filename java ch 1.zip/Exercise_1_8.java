
public class Exercise_1_8 {

	public static void main(String[] args) {
		System.out.println("The area of the circle is: ");
		System.out.println(3.14 * (5.5 * 5.5));
		System.out.println("The Perimeter of the circle is: ");
		System.out.println(2 * 5.5 * 3.14);
	}

}
