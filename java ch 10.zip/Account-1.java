import java.util.*;

public class Account {
	private int id;
	private double balance;
	
	Account() {
		id = 0;
		balance = 100;
	}
	
	Account(int newId, double newBalance) {
		id = newId;
		balance = newBalance;
	}
	
	public int getId() {
		return this.id;
	}
	public double getBalance() {
		return this.balance;
	}
	
	public void setId(int newId) {
		this.id = newId;
	}
	public void setBalance(double newBalance) {
		this.balance = newBalance;
	}
	
	double withdraw(double ammount) {
		balance -= ammount;
		return balance;
	}
	double deposit(double ammount) {
		balance += ammount;
		return balance;
	}
}
