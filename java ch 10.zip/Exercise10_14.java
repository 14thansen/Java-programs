import java.util.*;

public class Exercise10_14 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		MyDate date1 = new MyDate();
		System.out.print("Enter the time elapsed in miliseconds: ");
		MyDate date2 = new MyDate(input.nextLong());
		
		System.out.println("Todays date: " + date1.getMonth() + ", " + date1.getDay() + ", " + date1.getYear());
		System.out.println("Specified date: " + date2.getMonth() + ", " + date2.getDay() + ", " + date2.getYear());
	}

}
