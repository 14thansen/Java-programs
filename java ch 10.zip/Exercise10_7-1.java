import java.util.*;

public class Exercise10_7 {

	public static void main(String[] args) {
		Account[] accounts = new Account[10];
		for(int i = 0; i < 10; i++)
			accounts[i] = new Account(i, 100.0);
		Scanner input = new Scanner(System.in);
		int menu = 0;
		
		System.out.print("Enter an id (-1 to exit): ");
		int id = input.nextInt();
		while (id != -1){
			if (id >= 0 && id <= 9){
				while (menu != 4){
					System.out.println("\nMain Menu" + "\n1: check balance" 
				          + "\n2: withdraw" + "\n3: deposit" + "\n4: Exit");
					System.out.print("Menu Option: ");
					menu = input.nextInt();
					
					if (menu == 1){
						System.out.printf("The balance is $%4.2f", accounts[id].getBalance());
					}else if (menu == 2){
						System.out.print("Withdrawl ammount: $");
						accounts[id].withdraw(input.nextDouble());
					}else if (menu == 3){
						System.out.print("Deposit ammount: $");
						accounts[id].deposit(input.nextDouble());
					}
				}
			}
			else
				System.out.println("Please enter a valid id.");
			System.out.print("Enter an id (-1 to exit): ");
			id = input.nextInt();
			menu = 0;
		}
	}

}
