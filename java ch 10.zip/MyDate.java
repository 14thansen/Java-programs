import java.util.*;

public class MyDate {
	private int year;
	private int month;
	private int day;
	GregorianCalendar calendar = new GregorianCalendar();
	//default constructor
	MyDate(){
		year = calendar.get(GregorianCalendar.YEAR);
		month = calendar.get(GregorianCalendar.MONTH);
		day = calendar.get(GregorianCalendar.DATE);
	}
	//specified constructor
	MyDate(long elapsedTime){
		calendar.setTimeInMillis(elapsedTime);
		year = calendar.get(GregorianCalendar.YEAR);
		month = calendar.get(GregorianCalendar.MONTH);
		day = calendar.get(GregorianCalendar.DATE);
	}
	
	//getters
	public int getYear() {
		return this.year;
	}
	public int getMonth() {
		return this.month;
	}
	public int getDay() {
		return this.day;
	}
	
	//set new date
	long setDate(long elapsedTime) {
		return elapsedTime;
	}
	
}
