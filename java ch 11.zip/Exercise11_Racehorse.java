import java.util.*;

public class Exercise11_Racehorse {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Horses name: ");
		RaceHorse horse1 = new RaceHorse();
		horse1.setName(input.nextLine());
		System.out.print("Horses color: ");
		horse1.setColor(input.nextLine());
		System.out.print("Horses birth year: ");
		horse1.setAge(input.nextInt());
		System.out.print("Number of previous races: ");
		horse1.setRaces(input.nextInt());
		
		System.out.println("\n" + horse1.getName() + " is a " + horse1.getColor() + " horse, born in " 
				+ horse1.getAge() + " and has competed in " + horse1.getRaces() + " races.");
	}

}
