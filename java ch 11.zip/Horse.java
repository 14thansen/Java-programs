
public class Horse {
	private String name;
	private String color;
	private int age;
	
	public String getName() {
		return this.name;
	}
	public String getColor() {
		return this.color;
	}
	public int getAge() {
		return this.age;
	}
	
	public void setName(String newName) {
		name = newName;
	}
	public void setColor(String newColor) {
		color = newColor;
	}
	public void setAge(int newAge) {
		age = newAge;
	}
}
