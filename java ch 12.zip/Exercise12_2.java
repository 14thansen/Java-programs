import java.util.*;

public class Exercise12_2 {
	
	public static int sum(int number1, int number2){
		return number1 + number2;
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);
		boolean go = false;
		int number1;
		int number2;
		while (go == false){
			try {
				System.out.print("Enter two integers: ");
				number1 = input.nextInt();
				number2 = input.nextInt();
				
				System.out.println(number1 + " + " + number2 + " = " + sum(number1, number2));
				go = true;
			}
			catch (InputMismatchException ex) {
				System.out.println("Whoops! Both numbers should be integers.\n");
				input.nextLine();
			}
		}
		
	}

}