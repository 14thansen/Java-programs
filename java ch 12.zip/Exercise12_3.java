import java.util.*;

public class Exercise12_3 {
	
	public static int randomNum(){
		return (int)(Math.random()*100);
	}

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int[] numbers = new int[100];
		for (int i = 0; i < numbers.length - 1; i++)
			numbers[i] = randomNum();
		int index;
		boolean go = false;
		
		while (go == false)
			try{
				System.out.print("Enter the index of the array: ");
				index = input.nextInt();
				
				System.out.println(numbers[index]);
				go = true;
			} 
			catch (ArrayIndexOutOfBoundsException ex){
				System.out.println("Whoops, thats out of bounds. Index should be less than 99.");
				input.nextLine();
		}
	}

}
