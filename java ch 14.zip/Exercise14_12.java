package ch.assignments;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import javafx.scene.shape.Rectangle;
        
public class Exercise14_12 extends Application {
    @Override
    public void start(Stage primaryStage) {
        //create a pane
        Pane pane = new Pane();
        
        //create rectangles
        Rectangle r1 = new Rectangle(15, 200 - (200 * .20), 90, 200 * .20);
        r1.setStroke(Color.BLACK);
        r1.setFill(Color.RED);
        pane.getChildren().add(new Text(15, 200 - (200 * .20) - 8,
                "Project - 20%"));
        pane.getChildren().add(r1);
        
        Rectangle r2 = new Rectangle(110, 200 - (200 * .10), 90, 200 * .10);
        r2.setStroke(Color.BLACK);
        r2.setFill(Color.BLUE);
        pane.getChildren().addAll(new Text(110, 200 - (200 * .10) - 8,
                "Quiz - 10%"), r2);
        
        Rectangle r3 = new Rectangle(205, 200 - (200 * .30), 90, 200 * .30);
        r3.setStroke(Color.BLACK);
        r3.setFill(Color.GREEN);
        pane.getChildren().addAll(new Text(205, 200 - (200 * .30) - 8,
                "Midterm - 30%"), r3);
        
        Rectangle r4 = new Rectangle(300, 200 - (200 * .40), 80, (200 * .40));
        r4.setStroke(Color.BLACK);
        r4.setFill(Color.YELLOW);
        pane.getChildren().addAll(new Text(300, 200 - (200 * .40) - 8,
                "Final - 40%"), r4);
        
        //Create a scene
        Scene scene = new Scene(pane, 395, 215);
        primaryStage.setTitle("Exercise14_12");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        Application.launch(args);
    }
}
