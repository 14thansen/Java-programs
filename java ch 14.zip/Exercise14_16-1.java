package ch.assignments;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Line;

public class Exercise14_16 extends Application{
    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();
        
        Line vLine1 = new Line(33, 0, 33, 100);
        vLine1.startXProperty().bind(pane.widthProperty().divide(3));
        vLine1.endXProperty().bind(pane.widthProperty().divide(3));
        vLine1.endYProperty().bind(pane.heightProperty());
        vLine1.setStroke(Color.RED);
        
        Line vLine2 = new Line(66, 0, 66, 100);
        vLine2.startXProperty().bind(pane.widthProperty().multiply(2).divide(3));
        vLine2.endXProperty().bind(pane.widthProperty().multiply(2).divide(3));
        vLine2.endYProperty().bind(pane.heightProperty());
        vLine2.setStroke(Color.RED);
        
        Line hLine1 = new Line(0, 33, 100, 33);
        hLine1.startYProperty().bind(pane.heightProperty().divide(3));
        hLine1.endYProperty().bind(pane.heightProperty().divide(3));
        hLine1.endXProperty().bind(pane.widthProperty());
        hLine1.setStroke(Color.BLUE);
        
        Line hLine2 = new Line(0, 66, 100, 66);
        hLine2.startYProperty().bind(pane.heightProperty().multiply(2).divide(3));
        hLine2.endYProperty().bind(pane.heightProperty().multiply(2).divide(3));
        hLine2.endXProperty().bind(pane.widthProperty());
        hLine2.setStroke(Color.BLUE);
        
        pane.getChildren().addAll(vLine1, vLine2, hLine1, hLine2);
        
        Scene scene = new Scene(pane, 100, 100);
        primaryStage.setTitle("Exercise14_16");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        Application.launch(args);
    }
}
