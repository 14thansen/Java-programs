import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class Exercise15_11 extends Application{
    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();
        Circle circle = new Circle(150, 150, 10);
        circle.setStroke(Color.BLACK);
        circle.setFill(Color.WHITE);
        
        pane.getChildren().add(circle);
        circle.setFocusTraversable(true);
        circle.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.DOWN)
                circle.setCenterY(circle.getCenterY() + 10);
            else if (e.getCode() == KeyCode.UP)
                circle.setCenterY(circle.getCenterY() - 10);
            else if (e.getCode() == KeyCode.LEFT)
                circle.setCenterX(circle.getCenterX() - 10);
            else if (e.getCode() == KeyCode.RIGHT)
                circle.setCenterX(circle.getCenterX() + 10);
            else
                System.out.println("Invalid key pressed");
        });
        
        Scene scene = new Scene(pane, 300, 300);
        primaryStage.setTitle("Exercise15_11");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        //circle.requestFocus();
    }
    
    public static void main(String[] args) {
        Application.launch(args);
    }
}
