import javafx.animation.PathTransition;
import javafx.animation.FadeTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Exercise15_26 extends Application{
    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();
        
        Circle circle = new Circle (150, 150, 25);
        circle.setFill(Color.BLUE);
        
        Arc arc = new Arc();
        arc.setCenterX(150);
        arc.setCenterY(125);
        arc.setRadiusX(125);
        arc.setRadiusY(50);
        arc.setStartAngle(190);
        arc.setLength(160);
        arc.setType(ArcType.OPEN);
        arc.setStroke(Color.BLACK);
        arc.setFill(Color.WHITE);
        
        pane.getChildren().addAll(arc, circle);
        
        PathTransition pt = new PathTransition();
        pt.setDuration(Duration.millis(3000));
        pt.setPath(arc);
        pt.setNode(circle);
        pt.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        pt.setCycleCount(Timeline.INDEFINITE);
        pt.setAutoReverse(true);
        pt.play();
        
        FadeTransition ft = new FadeTransition(Duration.millis(3000), circle);
        ft.setFromValue(1.0);
        ft.setToValue(0.1);
        ft.setCycleCount(Timeline.INDEFINITE);
        ft.setAutoReverse(true);
        ft.play();
        
        circle.setOnMousePressed(e -> {
            pt.pause(); ft.pause();
        });
        circle.setOnMouseReleased(e -> {
            pt.play(); ft.play();
        });
        
        Scene scene = new Scene(pane, 300, 225);
        primaryStage.setTitle("Exercise15_26");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        Application.launch(args);
    }
}
