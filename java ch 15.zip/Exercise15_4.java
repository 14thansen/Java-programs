import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Exercise15_4 extends Application{
    private TextField tfNum1 = new TextField();
    private TextField tfNum2 = new TextField();
    private TextField tfResult = new TextField();
    private Button bAdd = new Button("Add");
    private Button bSubtract = new Button("Subtract");
    private Button bMultiply = new Button("Multiply");
    private Button bDivide = new Button("Divide");
    private Button bClear = new Button("Clear");
    
    @Override
    public void start(Stage primaryStage) {
        //create UI
        FlowPane pane = new FlowPane();
        pane.setPadding(new Insets(15,15,15,15));
        pane.setHgap(5);
        pane.setVgap(10);
        
        pane.getChildren().add(new Label("Number 1:"));
        tfNum1.setPrefColumnCount(4);
        pane.getChildren().add(tfNum1);
        pane.getChildren().add(new Label("Number 2:"));
        tfNum2.setPrefColumnCount(4);
        pane.getChildren().add(tfNum2);
        pane.getChildren().add(new Label("Result:"));
        tfResult.setPrefColumnCount(4);
        pane.getChildren().addAll(tfResult, bAdd, bSubtract,
                bMultiply, bDivide, bClear);
        
        //set properties for UI
        pane.setAlignment(Pos.CENTER);
        tfResult.setEditable(false);
        
        
        //process events
        bAdd.setOnAction(e -> {
            double result = getNum1() + getNum2();
            tfResult.setText(String.valueOf(result));
        });
        bSubtract.setOnAction(e -> {
            double result = getNum1() - getNum2();
            tfResult.setText(String.valueOf(result));
        });
        bMultiply.setOnAction(e -> {
            double result = getNum1() * getNum2();
            tfResult.setText(String.valueOf(result));
        });
        bDivide.setOnAction(e -> {
            double result = getNum1() / getNum2();
            tfResult.setText(String.valueOf(result));
        });
        bClear.setOnAction(e -> {
            tfNum1.setText("");
            tfNum2.setText("");
            tfResult.setText("");
        });
        
        //create scene
        Scene scene = new Scene(pane, 450, 100);
        primaryStage.setTitle("Excercise15_4");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    private double getNum1() {
        double num1 = Double.parseDouble(tfNum1.getText());
        return num1;
    }
    private double getNum2() {
        double num2 = Double.parseDouble(tfNum2.getText());
        return num2;
    }
    
    public static void main(String[] args) {
        Application.launch(args);
    }
}
