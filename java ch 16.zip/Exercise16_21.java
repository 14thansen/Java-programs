import javafx.application.Application;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.util.Duration;
import java.io.File;

public class Exercise16_21 extends Application {
	private Integer startTime = 0;
	private Timeline timeline;
	private TextField tfTimer = new TextField();
	private Integer timeSeconds = startTime;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void start(Stage primaryStage) {
		tfTimer.setStyle("-fx-font-size: 4em");
		tfTimer.setAlignment(Pos.CENTER);
		tfTimer.setText("Enter Seconds");
		MediaPlayer mp = new MediaPlayer(new Media("http://www.cs.armstrong.edu/liang/common/audio/anthem/anthem0.mp3"));
		tfTimer.setOnMouseClicked(e -> {
			tfTimer.setText(null);
			tfTimer.setStyle("-fx-font-size: 7em");
		});
		
		tfTimer.setOnAction(e -> {
			if (timeline != null)
				timeline.stop();
			
			timeSeconds = Integer.parseInt(tfTimer.getText());
			tfTimer.setText(timeSeconds.toString());
			timeline = new Timeline();
			timeline.setCycleCount(Timeline.INDEFINITE);
			timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(1),
					new EventHandler() {
						@Override
						public void handle(Event event) {
							timeSeconds--;
							tfTimer.setText(timeSeconds.toString());
							if (timeSeconds <= 0) {
								timeline.stop();
								mp.play();
							}
						}
					}));
			timeline.playFromStart();
		});
		
		Scene scene = new Scene(tfTimer, 375, 270);
		primaryStage.setTitle("Exercise16_21");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}
}
