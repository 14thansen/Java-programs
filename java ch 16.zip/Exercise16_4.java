import javafx.application.Application;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
public class Exercise16_4 extends Application {
	protected GridPane getPane() {
		GridPane pane = new GridPane();
		pane.setHgap(5);
		pane.setVgap(5);
		pane.setAlignment(Pos.CENTER);
		
		Label lbMile = new Label("Mile");
		Label lbKm = new Label("Kilometer");
		TextField tfMile = new TextField();
		TextField tfKm = new TextField();
		tfMile.setAlignment(Pos.BOTTOM_RIGHT);
		tfKm.setAlignment(Pos.BOTTOM_RIGHT);
		
		pane.add(lbMile, 0, 0);
		pane.add(lbKm, 0, 1);
		pane.add(tfMile, 1, 0);
		pane.add(tfKm, 1, 1);
		
		tfMile.setOnAction(e -> {
			//if (tfMile.getText().)
			double km = Double.parseDouble(tfMile.getText()) * 1.609344;
			tfKm.setText(Double.toString(km));
		});
		tfKm.setOnAction(e -> {
			double mile = Double.parseDouble(tfKm.getText()) / 1.609344;
			tfMile.setText(Double.toString(mile));
		});
		
		return pane;
		
	}
	
	@Override
	public void start(Stage primaryStage) {
		Scene scene = new Scene(getPane(), 250, 75);
		primaryStage.setTitle("Exercise16_4");
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}

}
