import javafx.application.Application;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.shape.*;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;

public class Exercize16_2 extends Application {
	protected Circle circle = new Circle(50, 100, 25);
	protected Rectangle rectangle = new Rectangle(40, 20, 40, 20);
	protected Ellipse ellipse = new Ellipse(50, 100, 50, 25);
	
	protected BorderPane getPane() {
		circle.setFill(Color.WHITE);
		circle.setStroke(Color.BLACK);
		rectangle.setFill(Color.WHITE);
		rectangle.setStroke(Color.BLACK);
		ellipse.setFill(Color.WHITE);
		ellipse.setStroke(Color.BLACK);
		
		HBox buttonPane = new HBox(20);
		buttonPane.setPadding(new Insets(5, 5, 5, 5));
		buttonPane.setStyle("-fx-border-Color: black");
		buttonPane.setAlignment(Pos.CENTER);
		
		BorderPane pane = new BorderPane();
		pane.setBottom(buttonPane);
		
		Pane imagePane = new Pane();
		imagePane.getChildren().add(circle);
		pane.setCenter(imagePane);
		
		circle.centerXProperty().bind(imagePane.widthProperty().divide(2));
		circle.centerYProperty().bind(imagePane.heightProperty().divide(2));
		circle.radiusProperty().bind(imagePane.heightProperty().divide(2).subtract(15));
		
		rectangle.xProperty().bind(imagePane.widthProperty().divide(4));
		rectangle.yProperty().bind(imagePane.heightProperty().divide(4));
		rectangle.widthProperty().bind(imagePane.widthProperty().divide(2));
		rectangle.heightProperty().bind(imagePane.heightProperty().divide(2));
		
		ellipse.centerXProperty().bind(imagePane.widthProperty().divide(2));
		ellipse.centerYProperty().bind(imagePane.heightProperty().divide(2));
		ellipse.radiusXProperty().bind(imagePane.widthProperty().divide(3));
		ellipse.radiusYProperty().bind(imagePane.heightProperty().divide(3));
		
		RadioButton rbCircle = new RadioButton("Circle");
		RadioButton rbRectangle = new RadioButton("Rectangle");
		RadioButton rbEllipse = new RadioButton("Ellipse");
		CheckBox cbFill = new CheckBox("Fill");
		buttonPane.getChildren().addAll(rbCircle, rbRectangle, rbEllipse, cbFill);
		
		cbFill.setOnAction(e -> {
			if (circle.getFill() == Color.WHITE) {
				circle.setFill(Color.BLUE);
				rectangle.setFill(Color.GREEN);
				ellipse.setFill(Color.RED);
			} else {
				circle.setFill(Color.WHITE);
				rectangle.setFill(Color.WHITE);
				ellipse.setFill(Color.WHITE);
			}
		});
		
		ToggleGroup group = new ToggleGroup();
		rbCircle.setToggleGroup(group);
		rbRectangle.setToggleGroup(group);
		rbEllipse.setToggleGroup(group);
		
		group.selectToggle(rbCircle);
		
		rbCircle.setOnAction(e -> {
			if (rbCircle.isSelected()) {
				imagePane.getChildren().removeAll(imagePane.getChildren());
				imagePane.getChildren().add(circle);
			}
		});
		rbRectangle.setOnAction(e -> {
			if (rbRectangle.isSelected()) {
				imagePane.getChildren().removeAll(imagePane.getChildren());
				imagePane.getChildren().add(rectangle);
			}
		});
		rbEllipse.setOnAction(e -> {
			if (rbEllipse.isSelected()){
				imagePane.getChildren().removeAll(imagePane.getChildren());
				imagePane.getChildren().add(ellipse);
			}
		});
		
		
		
		return pane;
	}
	
	@Override
	public void start(Stage primaryStage) {
		Scene scene = new Scene(getPane(), 450, 200);
		primaryStage.setTitle("Exercise16_2");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}

}
