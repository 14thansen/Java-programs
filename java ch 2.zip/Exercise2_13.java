import java.util.Scanner;
import java.text.DecimalFormat;

public class Exercise2_13 
{
	public static void main(String[] args) 
	{
		final double RATE = 0.00417;
		double account;
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(2);
		
		System.out.print("Enter the monthly saving amount: $");
		Scanner input = new Scanner(System.in);
		double savings = input.nextDouble();
		account = savings;
		
		account = account * (1 + RATE);
		account = (account + savings) * (1 + RATE);
		account = (account + savings) * (1 + RATE);
		account = (account + savings) * (1 + RATE);
		account = (account + savings) * (1 + RATE);
		account = (account + savings) * (1 + RATE);
		
		System.out.print("After 6 months, the account value will be: $" + df.format(account));
	}
}
