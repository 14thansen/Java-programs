import java.util.Scanner;

public class Exercise2_4
{
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		System.out.print("Number of Pounds: ");
		double pounds = input.nextDouble();
		double kilos = pounds * 0.454;
		System.out.println("Kilograms: " + kilos);
	}
}
