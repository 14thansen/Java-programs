import java.util.Scanner;
import java.text.DecimalFormat;

public class Exercise_2_23 
{
	public static void main(String[] args) 
	{
		double distance;
		double mpg;
		double cost;
		double totalCost;
		Scanner input = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(2);
		
		System.out.print("Enter the driving distance: ");
		distance = input.nextDouble();
		System.out.print("Enter miles per gallon: ");
		mpg = input.nextDouble();
		System.out.print("Enter price per gallon: $");
		cost = input.nextDouble();
		
		totalCost = (distance / mpg) * cost;
		System.out.print("The cost of driving is $" + df.format(totalCost));
	}
}
