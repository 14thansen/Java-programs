import java.util.Scanner;

public class Exercise3_18 
{
	public static void main(String[] args) 
	{
		//variables and objects
		Scanner input = new Scanner(System.in);
		double price;
		
		//ask user for input
		System.out.print("Enter package weight in pounds: ");
		double weight = input.nextDouble();
		
		//check weight parameters
		if (weight > 0 && weight <= 1)
			price = 3.50;
		else if (weight > 1 && weight <= 3)
			price = 5.50;
		else if (weight > 3 && weight <= 10)
			price = 8.50;
		else if (weight > 10 && weight <= 20)
			price = 10.50;
		else
			price = -1;
		//end if
		
		if (price > 0)
		{
			System.out.print("Cost of shipping: $");
			System.out.printf("%.2f", price);
		}	
		else
			System.out.println("Package cannot be shipped.");
	}
}
