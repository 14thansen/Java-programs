
public class Exercise3_24 
{
	public static void main(String[] args) 
	{
		//variables
		int suitNum = (int)(Math.random() * (5 - 1) + 1);
		int number = (int)(Math.random() * (14 - 1) + 1);
		char suit;
		char face;
		
		if (suitNum == 1)
			suit = 'H';
		else if (suitNum == 2)
			suit = 'D';
		else if (suitNum == 3)
			suit = 'C';
		else if (suitNum == 4)
			suit = 'S';
		else
			suit = ' ';
		//end if
		
		if (number > 10 || number == 1)
		{
			if (number == 11)
				face = 'J';
			else if (number == 12)
				face = 'Q';
			else if (number == 13)
				face = 'K';
			else if (number == 1)
				face = 'A';
			else 
				face = ' ';
			//end if
			System.out.println("Card picked: " + face + " of " + suit);
		}
		else
			System.out.println("Card picked: " + number + " of " + suit);
		//end if
		
	}
}
