import java.util.*;

public class Exercise3_23 
{
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		//collect info
		System.out.print("Employee's name: ");
		String name = input.next();
		System.out.print("Hours worked: ");
		int hours = input.nextInt();
		System.out.print("Hourly pay rate: ");
		double payRate = input.nextDouble();
		double grossPay = payRate * hours;
		System.out.print("Federal tax withholding rate (Decimal format): ");
		double fedTaxRate = input.nextDouble();
		double fedDeduction = fedTaxRate * grossPay;
		System.out.print("State tax withholding rate (Decimal format: ");
		double stateTaxRate = input.nextDouble();
		double stateDeduction = stateTaxRate * grossPay;
		
		//display info
		System.out.println("\n" + "Payroll statement: ");
		System.out.println("Employee name: " + name);
		System.out.println("Hours Worked: " + hours);
		System.out.println("Pay Rate: $" + payRate);
		System.out.println("Gross Pay: $" + grossPay);
		System.out.println("Deductions: ");
		System.out.println("Federal Withholding (" + fedTaxRate * 100 + "%): $" + grossPay * fedTaxRate);
		System.out.println("State withholding (" + stateTaxRate * 100 + "%): $" + grossPay * stateTaxRate);
		System.out.println("Total deduction: $" + fedDeduction + stateDeduction);
		System.out.println("Net Pay: $" + (grossPay - (fedDeduction + stateDeduction)));
	}
}
