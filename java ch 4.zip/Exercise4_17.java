import java.util.*;

public class Exercise4_17 
{
	public static void main(String[] args) 
	{
		//declare variables and objects
		Scanner input = new Scanner(System.in);
		int days = 0;
		
		//receive inputs from user
		System.out.print("Enter a year: ");
		int year = input.nextInt();
		System.out.print("Enter a month: ");
		String month = input.next();
		month = month.substring(0, 3);
		//Calculate which month
		if (month.equalsIgnoreCase("jan"))
			days = 31;
		else if (month.equalsIgnoreCase("feb"))
			if (year % 4 == 0)
				days = 29;
			else
				days = 28;
		else if (month.equalsIgnoreCase("mar"))
			days = 31;
		else if (month.equalsIgnoreCase("apr"))
			days = 30;
		else if (month.equalsIgnoreCase("may"))
			days = 31;
		else if (month.equalsIgnoreCase("jun"))
			days = 30;
		else if (month.equalsIgnoreCase("jul"))
			days = 31;
		else if (month.equalsIgnoreCase("aug"))
			days = 30;
		else if (month.equalsIgnoreCase("sep"))
			days = 31;
		else if (month.equalsIgnoreCase("oct"))
			days = 31;
		else if (month.equalsIgnoreCase("nov"))
			days = 30;
		else if (month.equalsIgnoreCase("dec"))
			days = 31;
		else
		{
			System.out.println("Invalid entry");
			System.exit(1);
		}
		//end if
		System.out.println(month + " " + year + " has " + days + " days");
	}
}
