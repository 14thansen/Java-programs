import java.util.*;

public class ch5_30 
{
	public static void main(String[] args) 
	{
		//declare variables and objects
		Scanner input = new Scanner(System.in);
		double amount = 0;
		
		//receive input information
		System.out.print("Money saved per month (enter -1 to exit): $");
		double money = input.nextDouble();
		System.out.print("Annual interest rate (in decimal form): ");
		double rate = input.nextDouble();
		System.out.print("Months of saving: ");
		int months = input.nextInt();
		
		//calculate
		while (money > 0)
		{
			for (int count = 0; count < months; count++)
			{
				amount = (money + amount) * (1 + (rate / 12));
			}
			System.out.printf("You will have saved $%4.2f", amount);
			
			//receive input information
			System.out.print("\n\nMoney saved per month (enter -1 to exit): $");
			money = input.nextDouble();
			System.out.print("Annual interest rate (in decimal form): ");
			rate = input.nextDouble();
			System.out.print("Months of saving: ");
			months = input.nextInt();
		}
	}
}
