
public class ch5_33 
{
	public static void main(String[] args) 
	{
		//declare variables
		int count = 1;
		int check = 0;
		
		//check for perfect numbers
		while (count < 10000)
		{
			for (int x = 1; x < count; x++)
			{
				if (count % x == 0)
					check += x;
				//end if
			}//end for
			if (check == count)
			{
				System.out.print("\n" + count + " = 1");
				for (int x = 1; x < count; x++)
					if (count % x == 0 && x != 1)
						System.out.print(" + " + x);
				
			}
			count++;
			check = 0;
		}//end while
	}
}