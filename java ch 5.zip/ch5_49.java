import java.util.*;

public class ch5_49 
{
	public static void main(String[] args) 
	{
		//declare variables and objects
		Scanner input = new Scanner(System.in);
		int vowels = 0;
		int cons = 0;
		
		//input string
		System.out.print("Enter a word or phrase: ");
		String word = input.nextLine();
		word = word.toUpperCase();
		
		//check for vowels
		for (int sub = 0; sub < word.length(); sub++)
		{
			if (word.charAt(sub) == 'A' || word.charAt(sub) == 'E' || word.charAt(sub) == 'I' || 
					word.charAt(sub) == 'O' || word.charAt(sub) == 'U')
				vowels += 1;
			else if (word.charAt(sub) != ' ')
				cons += 1;
			//end if
		}//end for
		System.out.println("Vowels: " + vowels);
		System.out.println("Consonants: " + cons);
	}
}
