import java.util.*;

public class Exercise6_18 
{
	// Main Method
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		System.out.println("Password must contain at least eight characters.");
		System.out.println("Password may only contain letters and digits.");
		System.out.println("Password must contain at least two digits.");
		System.out.print("\nEnter a password: ");
		String word = input.nextLine();
		checkPassword(word);
		
	}
	
	public static void checkPassword(String password)
	{
		int digits = 0;
		int nonDigits = 0;
		char test;
		for (int s = 0; s < password.length(); s++)
		{
			test = password.charAt(s);
			if (Character.isDigit(test))
				digits += 1;
			else if (!Character.isLetter(test))
				nonDigits += 1;
		}
		if (password.length() < 8 || digits < 2 || nonDigits != 0)
		{
			System.out.println("Invalid password: ");
			if (password.length() < 8)
				System.out.println("  Not at least eight characters");
			if (digits < 2)
				System.out.println("  Not enough digits");
			if (nonDigits != 0)
				System.out.println("  Use of non letters or digits");
		}
		else
			System.out.println("Valid password.");
	}

}
