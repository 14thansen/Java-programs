
public class Exercise6_38 {

	public static void main(String[] args) {
		for(int row = 0; row < 10; row++)
		{
			System.out.println(" ");
			for (int col = 0; col < 10; col++)
			{
				System.out.print(getRandomUpperCaseLetter() + " ");
			}
		}
		System.out.println(" ");
		for(int row = 0; row < 10; row++)
		{
			System.out.println(" ");
			for (int col = 0; col < 10; col++)
			{
				System.out.print(getRandomDigit() + " ");
			}
		}
	}
	public static char getRandomCharacter(char ch1, char ch2)
	{
		return (char)(ch1 + Math.random() * (ch2 - ch1 + 1));
	}
	public static char getRandomUpperCaseLetter(){
		return getRandomCharacter('A', 'Z');
	}
	public static char getRandomDigit(){
		return getRandomCharacter('0', '9');
	}
}
