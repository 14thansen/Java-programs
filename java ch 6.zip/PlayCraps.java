import java.util.*;

public class PlayCraps 
{

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		String roll = "";
		int turn = 0;
		int dice1 = 0;
		int dice2 = 0;
		int total = 0;
		int point = 0;
		
		System.out.print("Ready to play? Press enter to roll or type 'no' to exit...\n");
		roll = input.nextLine();
		while (roll.length() == 0)
		{
			//roll the dice
			dice1 = diceRoll();
			dice2 = diceRoll();
			total = dice1 + dice2;
			turn++;
			System.out.println("Your roll:\n" + dice1 + " and " + dice2);
			
			//rules of the game
			if (turn == 1)
			{
				if (total == 7 || total == 11)
				{
					System.out.println("You win! It's your turn still, roll again!.");
					turn = 0;
				}
				else if (total == 2 || total == 3 || total == 12)
				{
					System.out.println("Craps, you lose.");
					turn = 0;
				}
				else
				{
					point = total;
					System.out.println("Point is " + point);
				}//end if
			}//end if
			if (turn > 1)
			{
				if (total == point)
				{
					System.out.println("Good job, you win!\nIt's your turn still, roll again!");
					turn = 0;
				}
				else if (total == 7)
				{
					System.out.println("Sorry, you rolled a 7, you lose.\nNext player!");
					turn = 0;
				}
				else
				{
					System.out.println("You rolled a " + total + " no big deal!");
					turn++;
				}
			}
			
			//roll again
			if (turn == 0)
				System.out.print("Here's the come-out roll, press enter to roll or type 'no' to exit...\n");
			else if (turn == 1)
				System.out.print("Let's play the point, press enter to roll or type 'no' to exit...\n");
			else if (turn > 1)
				System.out.print("Let's try that again, press enter to roll or type 'no' to exit...\n");
			roll = input.nextLine();
		}
	}
	
	public static int diceRoll()
	{
		int dice = 1 + (int)(Math.random() * (6 - 1) + 1);
		return dice;
	}

}
