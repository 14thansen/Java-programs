
public class Assignment23 
{
	
	public static void main(String[] args) 
	{
		boolean lockers[] = new boolean[100];
		for (int i = 0; i < 100; i++)
			lockers[i] = false;
		int student = 1;
		int space = 1;
		
		for (int i = 0; i < 100; i++)
		{
			for (int j = space - 1; j < 100; j += space)
			{
				if (lockers[j] == true)
					lockers[j] = false;
				else
					lockers[j] = true;
			}//end for
			student++;
			space = student;
		}
		for (int i = 0; i < 100; i++)
		{
			if ((i+ 1) % 10 == 0)
			{
				if (lockers[i] == false)
					System.out.println("||");
				else
					System.out.println("[]");
			}
			else
			{
				if (lockers[i] == false)
					System.out.print("||" + " ");
				else
					System.out.print("[]" + " ");
			}
		}
	}

}
