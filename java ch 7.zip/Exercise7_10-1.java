import java.util.*;

public class Exercise7_10 
{
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		int list[] = new int[10];
		
		System.out.print("Enter 10 numbers seperated by spaces: ");
		for (int i = 0; i < 10; i++)
			list[i] = input.nextInt();
		int lowest = indexOfSmallestElement(list);
		System.out.println("The lowest number is " + list[lowest] + " and it is in position " + (lowest + 1));
	}
	
	public static int indexOfSmallestElement(int[] array)
	{
		int lowest = array[0];
		int lowestIndex = 0;
		for (int i = 0; i < 10; i++)
		{
			if (array[i] < lowest)
			{
				lowest = array[i];
				lowestIndex = i;
			}
		}
		return lowestIndex;
	}
}
