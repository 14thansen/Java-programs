import java.util.*;

public class Exercise7_15 
{
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		int list[] = new int[10];
		
		System.out.print("Enter 10 numbers seperated by spaces: ");
		for (int i = 0; i < 10; i++)
			list[i] = input.nextInt();
		int newList[] = eliminateDuplicates(list);
		System.out.println("List of numbers without duplicates: ");
		for (int i = 0; i < 10; i++)
		{
			if (newList[i] > 0)
				System.out.print(newList[i] + " ");
		}
	}
	
	public static int[] eliminateDuplicates(int[] array)
	{
		int newArray[] = new int[10];
		for (int i = 0; i < 10; i++)
		{
			for (int j = i + 1; j < 10; j++)
			{
				if (array[i] == array[j])
				{
					array[j] = -1;
				}	
			}
		}
		return array;
	}
}