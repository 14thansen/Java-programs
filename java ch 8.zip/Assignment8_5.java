import java.util.*;

public class Assignment8_5 
{
	
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		System.out.print("Rows: ");
		int row = input.nextInt();
		System.out.print("Columns: ");
		int column = input.nextInt();
		double[][] a = new double[row][column];
		double[][] b = new double[row][column];
		
		System.out.println("Enter matrix a:");
		for (int r = 0; r < row; r++){
			for (int c = 0; c < column; c++){
				a[r][c] = input.nextDouble();
			}
		}
		System.out.println("Enter matrix b:");
		for (int r = 0; r < row; r++){
			for (int c = 0; c < column; c++){
				b[r][c] = input.nextDouble();
			}
		}
		
		double[][] total = addMatrix(a, b);
		
		for (int r = 0; r < row; r++){
			if (r != (int)(row / 2))
				System.out.println(Arrays.toString(a[r]) + "   " + Arrays.toString(b[r]) + "   " + Arrays.toString(total[r]));
			else
				System.out.println(Arrays.toString(a[r]) + " + " + Arrays.toString(b[r]) + " = " + Arrays.toString(total[r]));
		}
	}
	
	public static double[][] addMatrix(double[][] a, double[][] b)
	{
		double[][] total = new double[a.length][a[1].length];
		for (int r = 0; r < a.length; r++){
			for (int c = 0; c < a[r].length; c++){
				total[r][c] = a[r][c] + b[r][c];
			}
		}
		return total;
	}

}
