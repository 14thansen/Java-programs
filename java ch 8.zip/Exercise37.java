import java.util.*;
public class Exercise37 {

	public static void main(String[] args) {
		//declare variables and objects
		Scanner input = new Scanner(System.in);
		final String[][] STATES = {{"Utah", "Salt Lake City"	},
						 	 	   {"California", "Sacramento"	},
						 	 	   {"Arizona", "Phoenix"		},
						 	 	   {"Nevada", "Carson City"		},
						 	 	   {"Idaho", "Boise"			},
						 	 	   {"Washington", "Olympia"		},
						 	 	   {"Oregon", "Salem"			},
						 	 	   {"Montana", "Helena"			},
						 	 	   {"Wyoming", "Cheyenne"		},
						 	 	   {"Colorado", "Denver"		}};
		int score = 0;
		String guess = " ";
		while (guess.length() > 0){
			System.out.println("\nPress [enter] with no entry at any time to exit.");
			for (int i = 0; 0 < 10; i++){
				System.out.print("What is the capital of " + STATES[i][0] + "? ");
				guess = input.nextLine();
				if (guess.equalsIgnoreCase(STATES[i][1])){
					System.out.println("Correct!");
					score++;
				}
				else
					System.out.println("Incorrect, the correct answer was " + STATES[i][1]);
				if (guess.length() == 0 || i == 9)
					break;
			}//end for
			//display score
			System.out.print("\nYou scored " + score + "/10, ");
			if (score == 10){
				System.out.print("perfect!");
				break;
			}else if (score >= 8){
				System.out.print("nice job!");
				break;
			}else if (score >= 6){
				System.out.print("not too bad.");
				break;
			}else if (score < 6){
				System.out.print("that was terrible, try again!");
				score = 0;
			}
		}
	}
}