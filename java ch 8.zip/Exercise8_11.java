import java.util.*;

public class Exercise8_11 {

	public static void main(String[] args) {
		//declare variables and objects
		Scanner input = new Scanner(System.in);
		char[][] game = new char[3][3];
		String binary = "";
		
		int count = 0;
		
		//receive input items
		System.out.print("Enter a number between 0 and 511 (-1 to exit): ");
		int code = input.nextInt();
		while (code >= 0){
			//convert number to binary
			binary = Integer.toBinaryString(code);
			while (binary.length() < 9){
				binary = "0" + binary;
			}//end while
			//store binary code as an array
			for (int r = 0; r < 3; r++){
				for (int c = 0; c < 3; c++){
					if (binary.charAt(count) == '0')
						game[r][c] = 'H';
					else
						game[r][c] = 'T';
					count++;
				}//end for
			}//end for
			
			//display heads and tails
			for (int r = 0; r < 3; r++){
				for (int c = 0; c < 3; c++){
					System.out.print(game[r][c] + " ");
				}
				System.out.println();
			}
			
			//receive input items again
			System.out.print("\nEnter a number between 0 and 511 (-1 to exit): ");
			code = input.nextInt();
			count = 0;
		}//end while
	}

}
