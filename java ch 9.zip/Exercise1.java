import java.util.*;

public class Exercise1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Width: ");
		double w = input.nextDouble();
		System.out.print("Hight: ");
		double h = input.nextDouble();
		
		Exercise1 rectangle = new Exercise1(w, h);
		System.out.println("Width: " + w + "\nHight: " + h + "\nArea: " + rectangle.getArea() 
					+ "\nPerimeter: " + rectangle.getPerimeter());
	}
	
	//constructors
	double width;
	double hight;
	
	//construct a 1x1 rectangle 
	Exercise1(){
		width = 1;
		hight = 1;
	}
	
	//construct a rectangle with specified dimensions
	Exercise1(double newWidth, double newHight){
		width = newWidth;
		hight = newHight;
	}
	
	//return the area and perimeter of the rectangle
	double getArea(){
		return width * hight;
	}
	
	double getPerimeter(){
		return 2 * (width + hight);
	}

}
