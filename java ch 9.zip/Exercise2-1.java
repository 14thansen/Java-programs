
public class Exercise2 {

	public static void main(String[] args) {
		Stock stock = new Stock ();
			
		System.out.println("Symbol: " + stock.symbol + "\nName: " + stock.name);
		System.out.printf("Yesterdays closing price: $%4.2f", stock.previousClosingPrice);
		System.out.printf("\nCurrent price: $%4.2f", stock.currentPrice);
		System.out.printf("\nPercent of Change: %4.2f", (stock.getChangePercent() * 100));
		System.out.print("%");
	}
	
}

class Stock {
	//data fields
		String symbol;
		String name;
		double previousClosingPrice;
		double currentPrice;
		
		//constructors
		Stock(){
			this.symbol = "ORCL";
			this.name = "Oracle Corporation";
			this.previousClosingPrice = 34.5;
			this.currentPrice = 34.35;
		}
		Stock(String newSymbol, String newName, double newLastPrice, double newCurrentPrice){
			this.name = newName;
			this.symbol = newSymbol;
			this.previousClosingPrice = newLastPrice;
			this.currentPrice = newCurrentPrice;
		}
		
		//methods
		double getChangePercent(){
			return currentPrice / previousClosingPrice;
		}
		
		void setName(String newName){
			this.name = newName;
		}
		void setSymbol(String newSymbol){
			this.symbol = newSymbol;
		}
		void setPreviousClosingPrice(double newLastPrice){
			this.previousClosingPrice = newLastPrice;
		}
		void setCurrentPrice(double newCurrentPrice){
			this.currentPrice = newCurrentPrice;
		}
}