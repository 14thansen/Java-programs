import java.util.Scanner;

public class Exercise9_8 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Fan fan1 = new Fan();
		System.out.print("Do you want the default fan: Y or N? ");
		String answer = input.next();
		if (answer.equalsIgnoreCase("n")){
			System.out.print("Turn fan on (Y or N): ");
			String on = input.next();
			if (on.equalsIgnoreCase("y")){
				fan1.setOn(true);
				System.out.print("Fan Speed (1, 2, or 3): ");
				fan1.setSpeed(input.nextInt());
			}
			System.out.print("Fan color: ");
			fan1.setColor(input.next());
			System.out.print("Fan size (radius in feet): ");
			fan1.setRadius(input.nextDouble());
		}
		
		//display fan features
		System.out.println("\n" + fan1.toString());
	}
}
